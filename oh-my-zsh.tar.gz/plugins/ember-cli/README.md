# Ember CLI

**Maintainers:** [BilalBudhani](http://www.github.com/BilalBudhani), [eubenesa](http://www.github.com/eubenesa)

Ember CLI (http://www.ember-cli.com/)

### List of Aliases

    alias es='ember serve'
    alias ea='ember addon'
    alias eb='ember build'
    alias ed='ember destroy'
    alias eg='ember generate'
    alias eh='ember help'
    alias ein='ember init'
    alias ei='ember install'
    alias et='ember test'
    alias eu='ember update'
    alias ev='ember version'
