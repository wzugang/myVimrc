## atom

Plugin for Atom, a cross platform text and code editor, available for Linux, Mac OS X, and Windows.

### Requirements

 * [Atom](https://atom.io/)

### Usage

 * If `at` command is called without an argument, launch Atom

 * If `at` is passed a directory, `cd` to it and open it in Atom

 * If `at` is passed a file, open it in Atom

 * if `att` command is called, it is equivalent to `at .`, opening the current folder in Atom
