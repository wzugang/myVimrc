dos2unix .vimrc
dos2unix .vimrc.vundle

cp .vimrc ~/.vimrc -a
cp .vimrc.vundle ~/.vimrc.vundle -a


