dos2unix .vimrc
dos2unix .vimrc.vundle

cp .vimrc ~/.vimrc -a
cp .vimrc.vundle ~/.vimrc.vundle -a

[ -d ~/.vim ] && rm -rf ~/.vim
mkdir ~/.vim
cp * ~/.vim -a
