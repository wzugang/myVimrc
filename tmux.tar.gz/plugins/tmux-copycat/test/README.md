## Tmux copycat test suite

This directory contains test files for tmux copycat.

Tests are written with the [expect tool](http://expect.sourceforge.net/).

### Dependencies

- [Vagrant](https://www.vagrantup.com/)

### Running the test suite

From the `tmux copycat` project top directory run:

    $ ./run-tests
